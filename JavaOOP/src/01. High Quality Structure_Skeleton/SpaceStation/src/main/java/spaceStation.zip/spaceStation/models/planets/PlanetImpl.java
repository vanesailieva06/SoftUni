package spaceStation.models.planets;

import java.util.ArrayList;
import java.util.Collection;

public abstract class PlanetImpl implements Planet {

    private String name;
    private Collection<String> items;

    public PlanetImpl(String name) {
        this.name = name;
        items = new ArrayList<>();
    }


    @Override
    public Collection<String> getItems() {
        return items;
    }

    @Override
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
