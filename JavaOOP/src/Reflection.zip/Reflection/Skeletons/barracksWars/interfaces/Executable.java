package Reflection.Skeletons.barracksWars.interfaces;

public interface Executable {

	String execute();

}
