package softuni.exam.models.entity;

public enum Rating {
    GOOD, BAD, UNKNOWN
}
