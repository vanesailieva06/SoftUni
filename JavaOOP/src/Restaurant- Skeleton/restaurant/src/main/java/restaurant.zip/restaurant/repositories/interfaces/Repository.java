package restaurant.repositories.interfaces;

import java.util.Collection;
import java.util.Map;

public interface Repository<T> {


    void add(T entity);

}
