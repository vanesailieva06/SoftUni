package spaceStation.core;

public class ControllerImpl implements Controller {

    @Override
    public String addAstronaut(String type, String astronautName) {
        return null;
    }

    @Override
    public String addPlanet(String planetName, String... items) {
        return null;
    }

    @Override
    public String retireAstronaut(String astronautName) {
        return null;
    }

    @Override
    public String explorePlanet(String planetName) {
        return null;
    }

    @Override
    public String report() {
        return null;
    }
}
