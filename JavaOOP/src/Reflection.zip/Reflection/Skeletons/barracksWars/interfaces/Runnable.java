package Reflection.Skeletons.barracksWars.interfaces;

public interface Runnable {
	void run();
}
