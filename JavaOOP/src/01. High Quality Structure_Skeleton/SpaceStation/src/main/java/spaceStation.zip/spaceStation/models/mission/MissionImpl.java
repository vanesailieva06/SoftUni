package spaceStation.models.mission;

import spaceStation.models.astronauts.Astronaut;
import spaceStation.models.planets.Planet;

import java.util.ArrayList;
import java.util.Collection;

public class MissionImpl implements Mission{

    private Planet planet;
    private Collection<Astronaut> astronauts;

    public MissionImpl() {
        astronauts = new ArrayList<>();
    }

    @Override
    public void explore(Planet planet, Collection<Astronaut> astronauts) {

    }
}
