package DefiningClasses.CatLady;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        Map<String,Cat> catsMap = new LinkedHashMap<>();
        while (!input.equals("End")){
            String breed = input.split(" ")[0];
            String name = input.split(" ")[1];
            Cat cat = null;
            switch (breed) {
                case "Siamese" -> {
                    int earSize = Integer.parseInt(input.split(" ")[2]);
                    cat = new Siamese(name, earSize);
                }
                case "StreetExtraordinaire" -> {
                    int decibels = Integer.parseInt(input.split(" ")[2]);
                    cat = new StreetExtraordinaire(name, decibels);
                }
                case "Cymric" -> {
                    int furLength = Integer.parseInt(input.split(" ")[2]);
                    cat = new Cymric(name, furLength);
                }
            }
            catsMap.put(name,cat);
            input = scanner.nextLine();
        }
        String nameToSearch = scanner.nextLine();
        if (catsMap.containsKey(nameToSearch)){
            System.out.println(catsMap.get(nameToSearch));
        }

    }
}
