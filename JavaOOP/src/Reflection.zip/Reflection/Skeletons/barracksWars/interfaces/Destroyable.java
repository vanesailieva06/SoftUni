package Reflection.Skeletons.barracksWars.interfaces;

public interface Destroyable {
    
    int getHealth();
    
    void setHealth(int health);
}
